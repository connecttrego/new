package com.trego.dto;


import lombok.Data;


@Data
public class CategoryDTO {

    private Long id;
    private String name;
    private String logo;

}
