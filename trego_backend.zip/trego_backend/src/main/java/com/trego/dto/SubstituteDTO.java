package com.trego.dto;

import lombok.Data;

@Data
public class SubstituteDTO {

    private long id;
    private String text;
}
