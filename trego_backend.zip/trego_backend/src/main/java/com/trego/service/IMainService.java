package com.trego.service;

import com.trego.dto.MainDTO;

public interface IMainService {
 public MainDTO loadAll(double lat, double lng);

}
